package Java_homework;

public class java_homework_page_195Q5_5 {

	public static void main(String[] args) {
	      System.out.println("  Kilo  Pounds | Pounds  Kilo");
	              
	      for(int i = 1, j = 1; i <= 200 && j <= 515; i+=2, j +=5 ) {
	    	              System.out.println(" | " + i + " | " + i*2.2 + " | "  + j + " | " + j/2.2 + " | ");
	    	               
	    	          }

	                  
	                  for(int j = 20; j <= 515; j+=5 ) {
	                      System.out.println(" | " + j + " | " + j/2.2 + " | ");
	                  }

		

	}

}
