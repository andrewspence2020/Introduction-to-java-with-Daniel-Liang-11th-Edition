package java_homework;

public class java_homework_page109_Q5_3 {
	System.out.printf("%-13s%-13s\n","Kilograms","Pounds");

	for (int i = 1; i <= 199; i++) 
	 System.out.printf("%-13d%-13.1f\n", i, i*2.2);

}
}
