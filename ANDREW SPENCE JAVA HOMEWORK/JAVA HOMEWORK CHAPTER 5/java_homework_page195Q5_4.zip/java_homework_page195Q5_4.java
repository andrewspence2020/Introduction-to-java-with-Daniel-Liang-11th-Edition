package Java_homework;

import java.util.Scanner;

@SuppressWarnings("unused")
public class java_homework_page195Q5_4 {
	public static void main(String[] args) {
		System.out.printf("%-13s%-13s\n", "Miles", "Kilometers");
		
		//rounds the answer
	  double no=1.609;
	  for(int i=1;i<=10;i++)
		{
			
			
		   
		}
		
			
			
		

		
		
		
			
			

		
		

		for (int i = 1; i <= 10 ; i++) 
		 System.out.printf("%-13d%-13.1f\n", i,no * i);

	

  }

}